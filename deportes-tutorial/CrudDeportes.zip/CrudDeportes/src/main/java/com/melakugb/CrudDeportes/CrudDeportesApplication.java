package com.melakugb.CrudDeportes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudDeportesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudDeportesApplication.class, args);
	}

}
